# MYMENSINGH CYBER LAB

ডিজিটাল প্রোডাক্ট মার্কেটপ্লেস — Node.js + Express + EJS

## প্রথমবার সেটআপ

1. GitHub-এ আপলোড করুন
2. Railway-তে Deploy করুন
3. সাইট চালু হলে যান: `https://yoursite.com/setup`
4. অ্যাডমিন অ্যাকাউন্ট তৈরি করুন
5. `/setup` চিরতরে বন্ধ হয়ে যাবে

## লোকালি চালাতে

```bash
npm install
node server.js
```

তারপর: http://localhost:3000/setup

## Railway Deploy

- Environment Variable: `SESSION_SECRET=যেকোনো-লম্বা-পাসওয়ার্ড`
- Start Command: `node server.js`
